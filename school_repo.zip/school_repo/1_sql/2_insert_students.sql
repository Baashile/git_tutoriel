TRUNCATE TABLE Students CASCADE;


INSERT INTO Students (student_id, first_name, last_name, date_of_birth, address)
VALUES
(1 ,'John', 'Doe', '2004-02-12', '123 Main St.'),
(2 ,'Jane', 'Smith', '2004-05-21', '456 Elm St.'),
(3 ,'Bob', 'Johnson', '2004-08-02', '789 Oak Ave.'),
(4 ,'Sarah', 'Williams', '2004-11-15', '321 Maple St.'),
(5 ,'Mike', 'Davis', '2004-02-28', '654 Pine Ave.'),
(6 ,'Lisa', 'Nguyen', '2004-06-10', '987 Cedar St.'),
(7 ,'David', 'Lee', '2004-09-23', '246 Birch Ave.'),
(8 ,'Emily', 'Chen', '2004-12-06', '369 Juniper St.'),
(9 ,'Javier', 'Rodriguez', '2004-03-19', '582 Magnolia Ave.'),
(10 ,'Avery', 'Wilson', '2004-06-01', '795 Willow St.'),
(11 ,'Maxwell', 'Smith', '2004-09-14', '128 Spruce Ave.'),
(12 ,'Olivia', 'Kim', '2004-12-27', '461 Laurel St.'),
(13 ,'Brandon', 'Jackson', '2004-03-12', '684 Fir Ave.'),
(14 ,'Jasmine', 'Patel', '2004-06-25', '937 Cedar St.'),
(15 ,'Hannah', 'Smith', '2004-09-07', '260 Pine Ave.'),
(16 ,'Samuel', 'Lee', '2004-12-20', '483 Birch Ave.'),
(17 ,'Olivia', 'Chen', '2004-03-05', '706 Juniper St.'),
(18 ,'Isabella', 'Rodriguez', '2004-06-18', '929 Magnolia Ave.'),
(19 ,'Matthew', 'Wilson', '2004-09-30', '152 Willow St.'),
(20 ,'Liam', 'Kim', '2004-01-12', '375 Spruce Ave.');