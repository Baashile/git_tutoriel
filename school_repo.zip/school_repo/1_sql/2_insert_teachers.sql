TRUNCATE TABLE Teachers CASCADE;

INSERT INTO Teachers (teacher_id, first_name, last_name, subject)
VALUES
(1,'Mary', 'Johnson', 'Mathematics'),
(2,'Tom', 'Anderson', 'English'),
(3,'Susan', 'Davis', 'Science'),
(4,'Rachel', 'Lee', 'Music'),
(5,'Thomas', 'Davis', 'Art'),
(6,'Williams', 'Marshall', 'History'),
(7,'Bob', 'Frank', 'IT');